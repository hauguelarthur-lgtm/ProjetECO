#' Example JSON for driving
#'
#' Example JSON response from OTP
#' This is used for internal testing and has no use
#'
#' @format json
"json_example_drive"

#' Example JSON for transit
#'
#' Example JSON response from OTP
#' This is used for internal testing and has no use
#'
#' @format json
"json_example_transit"

#' Example JSON for driving long distance
#'
#' Example JSON response from OTP
#' This is used for internal testing and has no use
#'
#' @format json
"json_example_long_drive"
